cd 'C:\Users\netii\Documents\PDI\AP5'

[oldimage,map] = imread('ufo2.gif');

image = ind2gray(oldimage,map);

imageD = double(image);

figure;
subplot(1,3,1);
imshow(image);

H1 = [-1,-2,-1; 0,0,0; 1,2,1];
H2 = [-1,0,1; -2,0,2; -1,0,1];

imageborda = zeros(size(imageD) + 2);
imageborda(2:(size(imageborda,1)-1),2:(size(imageborda,2)-1)) = imageD;

imSobel = imageD./max(imageD(:));
imSobel = imSobel*255;

for i = 1 : (size(imageD,1))
  for j = 1 : (size(imageD,2))
    F1 = sum(sum(imageborda(i:i+2,j:j+2) .* H1));
    F2 = sum(sum(imageborda(i:i+2,j:j+2) .* H2));
    imSobel(i,j) = sqrt(F1.*F1 + F2.*F2);
  endfor
endfor
 
subplot(1,3,2);
imshow(uint8(imSobel));

subplot(1,3,3);

imSobel2 = imSobel > 150;
#imSobel2 = imSobel2./max(imSobel(:));
#imSobel2 = imSobel2.*255;
imshow(uint8(255*imSobel2));