cd 'C:\Users\netii\Documents\PDI\AP5'

[oldimage,map] = imread('cln1.gif');

image = ind2gray(oldimage,map);

imageD = double(image);

figure;
subplot(1,3,1);
imshow(image);

h1 = [1,0;0,-1];
h2 = [0,1;-1,0];

imRoberts = imageD;

for i = 1 : (size(imageD,1) -1)
  for j = 1 : (size(imageD,2) -1)
    f1 = sum(sum(imageD(i:i+1,j:j+1) .* h1));
    f2 = sum(sum(imageD(i:i+1,j:j+1) .* h2));
    imRoberts(i,j) = sqrt(f1.*f1 + f2.*f2); 
  endfor
endfor

subplot(1,3,2);
imshow(uint8(imRoberts));

##############################################################################

H1 = [-1,-2,-1; 0,0,0; 1,2,1];
H2 = [-1,0,1; -2,0,2; -1,0,1];

imSobel = imageD;

for i = 1 : (size(imageD,1) -2)
  for j = 1 : (size(imageD,2) -2)
    F1 = sum(sum(imageD(i:i+2,j:j+2) .* H1));
    F2 = sum(sum(imageD(i:i+2,j:j+2) .* H2));
    imSobel(i,j) = sqrt(F1.*F1 + F2.*F2);
  endfor
endfor

subplot(1,3,3);
imshow(uint8(imSobel));