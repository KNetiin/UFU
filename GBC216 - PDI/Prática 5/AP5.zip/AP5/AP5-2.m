cd 'C:\Users\netii\Documents\PDI\AP5'

[oldimage,map] = imread('cln1.gif');

image = ind2gray(oldimage,map);

imageD = double(image);
##
##figure;
##subplot(1,4,1);
##imshow(image);

mascara = [1,1,1; 1,-8,1; 1,1,1];

imagemborda = zeros(size(imageD)+2);
imagemborda(2:size(imagemborda,1)-1,2:size(imagemborda,2)-1) = imageD;

g = imageD;

for i = 1 : size(imageD,1)
  for j = 1 : size(imageD,2)
    matriz3 = imagemborda(i:i+2,j:j+2).*mascara;
    g(i,j) = sum(matriz3(:));
  endfor
endfor

imLaplaciano = imageD + (g.*(-1));
subplot(1,4,1);
imshow(uint8(imLaplaciano));

#################################################################################

imMediana = imageD;

for i = 1 : size(imageD,1)
  for j = 1 : size(imageD,2)
    matriz3 = imagemborda(i:i+2,j:j+2);
    imMediana(i,j) = median(matriz3(:));
  endfor
endfor

Gmask = imageD - imMediana;

imUnsharpMasking = imageD + Gmask;
imHighBoost = imageD + 3*Gmask;
imKmenor0 = imageD - 3*Gmask;

subplot(1,4,2);
imshow(uint8(imUnsharpMasking));
subplot(1,4,3);
imshow(uint8(imHighBoost));
subplot(1,4,4);
imshow(uint8(imKmenor0));