cd 'C:\Users\netii\Documents\PDI\AP3'
pkg load image;

image = imread('pout.tif');

figure;

subplot(2,2,1);
imshow(image);

subplot(2,2,2);
imhist(image);

imageEQ = histeq(image);
subplot(2,2,3);
imshow(imageEQ);

subplot(2,2,4);
imhist(imageEQ);

figure;

[histograma, T] = imhist(image);
histogramaN = histograma/sum(histograma(:));
curva = cumsum(histogramaN);
plot(curva);

