cd 'C:\Users\netii\Documents\PDI\AP3'

image = imread('im_cells.png');

figure;

subplot(1,3,1);
imshow(image);

imageNegativa = 255 - image;
subplot(1,3,2);
imshow(imageNegativa);

imageRevertida = 255 - imageNegativa;
subplot(1,3,3);
imshow(imageRevertida);