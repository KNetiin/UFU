cd 'C:\Users\netii\Documents\PDI\AP3'
pkg load image;

image = imread('im_cells.png');
##image = imread('pout.tif');

[histograma,T] = imhist(image);

histogramaN = histograma/sum(histograma(:));

curva = cumsum(histogramaN);

correto = uint8(curva*255);

imageE = correto(image+1);

figure;
subplot(2,2,1);
imshow(image);
subplot(2,2,2);
plot(curva);

subplot(2,2,3);
imshow(imageE);

[histograma2,T2] = imhist(imageE);
histogramaN2 = histograma2/sum(histograma2(:));
curva2 = cumsum(histogramaN2);

subplot(2,2,4);
plot(curva2);
