cd 'C:\Users\netii\Documents\PDI\AP3'

image = imread('im_cells.png');
figure;

subplot(1,2,1);
imshow(image);

imagedouble = double(image);
imagedouble = imagedouble + 1;

imageLog = log(imagedouble);
imageLog = imageLog/max(imageLog(:));
imageLog = uint8(255*imageLog);

subplot(1,2,2);
imshow(imageLog);