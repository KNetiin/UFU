cd 'C:/Users/netii/Documents/PDI/AP2'

matriz = double(imread('art8.png'));
%matriz = [0,0,0,0,0,0,0 ; 0,0,1,1,0,1,0 ; 1,1,1,1,0,1,1 ; 0,1,1,1,0,0,0 ; 1,1,0,0,0,0,0 ; 0,0,0,0,0,0,0]

imagem1 = uint8(matriz*255);

cont = 2;

for i = 1 : size(matriz,1)
  for j = 1 : size(matriz,2)

    if(matriz(i,j) == 1) 
      
      matriz(i,j) = cont;
      cont++;
      
      if( (j-1 > 0) && (matriz(i,j-1) != 0) )
        matriz(i,j) = matriz(i,j-1);
        cont--;
      endif
      
      if( (i-1 > 0) && (matriz(i-1,j) != 0) && (matriz(i-1,j) != matriz(i,j)) )
        
        if(matriz(i-1,j) < matriz(i,j))
          aux = ( (matriz == matriz(i,j)) * (matriz(i,j) - matriz(i-1,j)) );
        else
          aux = ( (matriz == matriz(i-1,j)) * (matriz(i-1,j) - matriz(i,j)) );
        end
        matriz = matriz - aux;
      endif
      
    endif
    
  endfor
endfor

figure();

subplot(1,3,1)
imshow(imagem1);

matriz2 = matriz/1.5;
imagem = uint8(matriz2);
subplot(1,3,2)
imshow(imagem);

auxcolor = (matriz > 0);%ones(size(matriz));
rgbImage = ind2rgb(imagem,colorcube(256));

imagem3(:,:,1) = double(rgbImage(:,:,1)).*auxcolor;
imagem3(:,:,2) = double(rgbImage(:,:,2)).*auxcolor;
imagem3(:,:,3) = double(rgbImage(:,:,3)).*auxcolor;

subplot(1,3,3)
%imshow(rgbImage);
imshow(imagem3);