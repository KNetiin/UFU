cd 'C:/Users/netii/Documents/PDI/AP2'

matriz = double(imread('clc3.png'));

%BINARIZANDO A IMAGEM:
matriz = double(matriz > 67);

cc = bwconncomp(matriz);