cd 'C:/Users/netii/Documents/PDI/AP2'

image = imread('clc3.png');
matriz = double(imread('clc3.png'));

figure();
subplot(1,3,1);
imshow(image);

%BINARIZANDO A IMAGEM:
matriz = double(matriz > 67);

image2 = uint8(matriz*255);

subplot(1,3,2);
imshow(image2);

cont = 2;

for i = 1 : size(matriz,1)
  for j = 1 : size(matriz,2)
    if(matriz(i,j) == 1)
      
      matriz(i,j) = cont;
      menor = cont;
      cont++;
      diminuir = 0;
      
      esquerda = double(zeros(size(matriz)));
      cima = double(zeros(size(matriz)));
      direita = double(zeros(size(matriz)));
      baixo = double(zeros(size(matriz)));
      esquerdacima = double(zeros(size(matriz)));
      esquerdabaixo = double(zeros(size(matriz)));
      direitacima = double(zeros(size(matriz)));
      direitabaixo = double(zeros(size(matriz)));
      
      
      if((j-1 > 0) && (matriz(i,j-1) > 1))
        if(matriz(i,j-1) < menor)
          esquerda = double( matriz == menor );
          menor = matriz(i,j-1);
          diminuir = 1;
        elseif
          esquerda = double( matriz == matriz(i,j-1) );
        end
      endif
      
      if((i-1 > 0) && (matriz(i-1,j) > 1))
        if(matriz(i-1,j) < menor)
          cima = double( matriz == menor );
          menor = (matriz(i-1,j));
          diminuir = 1;
        elseif
          cima = double( matriz == matriz(i-1,j) );
        end
      endif
      
      if((j+1 <= size(matriz,2)) && (matriz(i,j+1) > 1))
        if(matriz(i,j+1) < menor)
          direita = double( matriz == menor );
          menor = (matriz(i,j+1));
          diminuir = 1;
        elseif
          direita = double( matriz == matriz(i,j+1) );
        end  
      endif
      
      if((i+1 <= size(matriz,1)) && (matriz(i+1,j) > 1))
        if(matriz(i+1,j) < menor)
          baixo = double( matriz == menor );
          menor = (matriz(i+1,j));
          diminuir = 1;
        elseif
          baixo = double( matriz == matriz(i+1,j) );
        end
      endif
      
      if((j-1 > 0) && (i-1 > 0) && (matriz(i-1,j-1) > 1))
        if(matriz(i-1,j-1) < menor)
          esquerdacima = double( matriz == menor );
          menor = (matriz(i-1,j-1));
          diminuir = 1;
        elseif
          esquerdacima = double( matriz == matriz(i-1,j-1) );
        end
      endif
      
      if((j+1 <= size(matriz,2)) && (i-1 > 0) && (matriz(i-1,j+1) > 1))
        if(matriz(i-1,j+1) < menor)
          direitacima = double( matriz == menor );
          menor = (matriz(i-1,j+1));
          diminuir = 1;
        elseif
          direitacima = double( matriz == matriz(i-1,j+1) );
        end
      endif
      
      if((j+1 <= size(matriz,2)) && (i+1 <= size(matriz,1)) && (matriz(i+1,j+1) > 1))
        if(matriz(i+1,j+1) < menor)
          direitabaixo = double( matriz == menor );
          menor = (matriz(i+1,j+1));
          diminuir = 1;
        elseif
          direitabaixo = double( matriz == matriz(i+1,j+1) );
        end
      endif
      
      if((j-1 > 0) && (i+1 <= size(matriz,1)) && (matriz(i+1,j-1) > 1))
        if(matriz(i+1,j-1) < menor)
          esquerdabaixo = double( matriz == menor );
          menor = (matriz(i+1,j-1));
          diminuir = 1;
        elseif
          esquerdabaixo = double( matriz == matriz(i+1,j-1) );
        end
      endif
      
      if(diminuir == 1)
        cont--;
        total = cima + baixo + direita + esquerda + esquerdabaixo + esquerdacima + direitabaixo + direitacima;
        total = double(total > 0);
        manter = double(ones(size(matriz)) - total);
        total = total * menor;
        manter = manter .* matriz;
        matriz = total + manter;
      endif
  
    endif
  endfor
endfor

subplot(1,3,3);
imshow(uint8(matriz));