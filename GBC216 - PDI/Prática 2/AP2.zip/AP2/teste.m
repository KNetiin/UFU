%A = 1;
%B = 2;

%if(A == 1 && B == 2)
%  A = 2;
%elseif(A == 1 && B == 1)
%  A = 3;
%end
%B = 10;

%for i = 2 : -1 : 1
%  c = i
%endfor


cd 'C:/Users/netii/Documents/PDI/AP2'

A = imread('art8lab2.png');
figure
imshow(A)


cont2 = 1;
matriz2 = matriz;
for i = 1 : size(matriz2,1)
  for j = 1 : size(matriz2,2)

    if(matriz2(i,j) != 0 && matriz2(i,j) > cont2)
      (matriz2 == matriz2(i,j)) * cont2;
      cont2++;
    endif 
    
  endfor
endfor

cont2


matrizc = matriz;


%INVERTENDO PRETO COM BRANCO
maior128 = matrizc >= 128;
auxmaior = maior128 .* (-128);
menor128 = matrizc < 128;
auxmenor = menor128 .* (+128);
total = auxmaior.+auxmenor;
matrizinvertida = matrizc .+ total;

%BACKUP

for i = 1 : size(matriz,1)
  for j = 1 : size(matriz,2)

    if(matriz(i,j) == 1) 
      
      matriz(i,j) = cont;
      cont++;
      
      if( (j-1 > 0) && (matriz(i,j-1) != 0) )
        matriz(i,j) = matriz(i,j-1);
        cont--;
      endif
      
      if( (i-1 > 0) && (matriz(i-1,j) != 0) && (matriz(i-1,j) != matriz(i,j)) )
        
        if(matriz(i-1,j) < matriz(i,j))
          aux = ( (matriz == matriz(i,j)) * (matriz(i,j) - matriz(i-1,j)) );
        else
          aux = ( (matriz == matriz(i-1,j)) * (matriz(i-1,j) - matriz(i,j)) );
        end
        matriz = matriz - aux;
      endif
      
    endif
    
  endfor
endfor

%BACKUP 2.0
cd 'C:/Users/netii/Documents/PDI/AP2'

image = imread('clc3.png');
matriz = double(imread('clc3.png'));

figure();
subplot(1,3,1);
imshow(image);

%BINARIZANDO A IMAGEM:
matriz = double(matriz > 67);

image2 = uint8(matriz*255);

subplot(1,3,2);
imshow(image2);

cont = 2;

for i = 1 : size(matriz,1)
  for j = 1 : size(matriz,2)

    if(matriz(i,j) == 1) 
      matriz(i,j) = cont;
      cont++;
      
      if( (j-1 > 0) && (matriz(i,j-1) != 0) )
        matriz(i,j) = matriz(i,j-1);
        cont--;
      endif
      
      if( (i-1 > 0) && (matriz(i-1,j) != 0) && (matriz(i-1,j) != matriz(i,j)) )
        
        if(matriz(i-1,j) < matriz(i,j))
          aux = ( (matriz == matriz(i,j)) * (matriz(i,j) - matriz(i-1,j)) );
        else
          aux = ( (matriz == matriz(i-1,j)) * (matriz(i-1,j) - matriz(i,j)) );
        end
        matriz = matriz - aux;
      endif
      
      if( (i-1 > 0) && (j-1 > 0) && (matriz(i-1,j-1) != 0) && (matriz(i-1,j-1) != matriz(i,j)) )
        
        if(matriz(i-1,j-1) < matriz(i,j))
          aux = ( (matriz == matriz(i,j)) * (matriz(i,j) - matriz(i-1,j-1)) );
        else
          aux = ( (matriz == matriz(i-1,j-1)) * (matriz(i-1,j-1) - matriz(i,j)) );
        end
        matriz = matriz - aux;
      endif
      
    endif
    
  endfor
endfor

image3 = uint8(matriz);

subplot(1,3,3);
imshow(image3);


cont2 = 1;
matriz2 = matriz;
for i = 1 : size(matriz2,1)
  for j = 1 : size(matriz2,2)

    if(matriz2(i,j) != 0 && matriz2(i,j) > cont2)
      (matriz2 == matriz2(i,j)) * cont2;
      cont2++;
    endif 
    
  endfor
endfor

cont2

