cd 'C:\Users\netii\Documents\PDI\AP4'

[oldimage, map] = imread('ben2.png');

image = ind2gray(oldimage,map);

function g = GaussXY(x,y,sigma)
  fator = (1/sqrt(2*pi*(sigma^2)));
  g = fator*exp( -(x.^2 + y.^2)/(2*(sigma.^2)));
endfunction

##########################MASCARA GAUSSIANA 5 - SIGMA 1##########################
mascara5 = zeros(5,5);
a = 2;
b = 2;
sigma = 1;

for x=-a:a
  for y=-b:b
    mascara5(x+a+1,y+b+1) = GaussXY(x,y,sigma);
  endfor
endfor
mascara5 = mascara5./sum(mascara5(:));

##########################MASCARA GAUSSIANA 9 - SIGMA 2##########################
mascara9 = zeros(9,9);
a = 4;
b = 4;
sigma = 2;

for x=-a:a
  for y=-b:b
    mascara9(x+a+1,y+b+1) = GaussXY(x,y,sigma);
  endfor
endfor
mascara9 = mascara9./sum(mascara9(:));

##########################MASCARA GAUSSIANA 5 - SIGMA 4##########################
mascara15 = zeros(15,15);
a = 7;
b = 7;
sigma = 4;

for x=-a:a
  for y=-b:b
    mascara15(x+a+1,y+b+1) = GaussXY(x,y,sigma);
  endfor
endfor
mascara15 = mascara15./sum(mascara15(:));

imageborda5 = zeros( (size(image) + 4) );
imageborda9 = zeros( (size(image) + 8) );
imageborda15 = zeros( (size(image) + 14) );

image5 = double(image);
image9 = double(image);
image15 = double(image);

imageborda5( 3:(size(imageborda5,1)-2),3:(size(imageborda5,2)-2) ) = image;
imageborda9( 5:(size(imageborda9,1)-4),5:(size(imageborda9,2)-4) ) = image;
imageborda15( 8:(size(imageborda15,1)-7),8:(size(imageborda15,2)-7) ) = image;

for i = 1 : size(image,1)
  for j = 1 : size(image,2)
    newimage = imageborda5(i : i+4, j : j+4);
    imageMascara = newimage.*mascara5;
    image5(i,j) = sum(imageMascara(:));
  endfor
endfor

for i = 1 : size(image,1)
  for j = 1 : size(image,2)
    newimage = imageborda9(i : i+8, j : j+8);
    imageMascara = newimage.*mascara9;
    image9(i,j) = sum(imageMascara(:));
  endfor
endfor

for i = 1 : size(image,1)
  for j = 1 : size(image,2)
    newimage = imageborda15(i : i+14, j : j+14);
    imageMascara = newimage.*mascara15;
    image15(i,j) = sum(imageMascara(:));
  endfor
endfor

figure();

subplot(1,4,1);
imshow(image);

subplot(1,4,2);
imshow(uint8(image5));

subplot(1,4,3);
imshow(uint8(image9));

subplot(1,4,4);
imshow(uint8(image15));

####################################################################################

[oldimageNew, map2] = imread('sta2noi2.png');

imageNew = uint8(255*ind2gray(oldimageNew,map2));

imageborda5New = zeros( (size(imageNew) + 4) );

image5New = double(imageNew);
imageborda5New( 3:(size(imageborda5New,1)-2),3:(size(imageborda5New,2)-2) ) = imageNew;

for i = 1 : size(imageNew,1)
  for j = 1 : size(imageNew,2)
    newimageNew = imageborda5New(i : i+4, j : j+4);
    imageMascaraNew = newimageNew.*mascara5;
    image5New(i,j) = sum(imageMascaraNew(:));
  endfor
endfor

figure;
subplot(1,4,1);
imshow(imageNew);

imageuint8 = uint8(image5New);
subplot(1,4,2);
imshow(imageuint8);

####################################################################################

[oldimageNew2, map] = imread('sta2.png');

imageNew2 = ind2gray(oldimageNew2,map);

imageborda9New2 = zeros( (size(imageNew2) + 8) );
image9New2 = double(imageNew2);
imageborda9New2( 5:(size(imageborda9New2,1)-4),5:(size(imageborda9New2,2)-4) ) = imageNew2;

for i = 1 : size(imageNew2,1)
  for j = 1 : size(imageNew2,2)
    newimageNew2 = imageborda9New2(i : i+8, j : j+8);
    imageMascaraNew2 = newimageNew2.*mascara9;
    image9New2(i,j) = sum(imageMascaraNew2(:));
  endfor
endfor


subplot(1,4,3);
imshow(imageNew2);

subplot(1,4,4);
imshow(uint8(image9New2));
