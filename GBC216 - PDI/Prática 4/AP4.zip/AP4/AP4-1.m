cd 'C:\Users\netii\Documents\PDI\AP4'

[oldimage, map] = imread('sta2.png');

image = ind2gray(oldimage,map);

imageborda = zeros( (size(image) + 2) );
imageborda7 = zeros( (size(image) + 6) );

image3 = double(image);
image3x3 = double(image);
image3x3x3 = double(image);
image7 = double(image);

mascara3 = ones(3,3);
mascara7 = ones(7,7);

imageborda( 2:(size(imageborda,1)-1),2:(size(imageborda,2)-1) ) = image;
for i = 1 : size(image,1)
  for j = 1 : size(image,2)
    newimage = imageborda(i : i+2, j : j+2);
    imageMascara = newimage.*mascara3;
    image3(i,j) = (1/9)*sum(sum(imageMascara));
  endfor
endfor

imageborda( 2:(size(imageborda,1)-1),2:(size(imageborda,2)-1) ) = image3;
for i = 1 : size(image,1)
  for j = 1 : size(image,2)
    newimage = imageborda(i : i+2, j : j+2);
    imageMascara = newimage.*mascara3;
    image3x3(i,j) = (1/9)*sum(sum(imageMascara));
  endfor
endfor

imageborda( 2:(size(imageborda,1)-1),2:(size(imageborda,2)-1) ) = image3x3;
for i = 1 : size(image,1)
  for j = 1 : size(image,2)
    newimage = imageborda(i : i+2, j : j+2);
    imageMascara = newimage.*mascara3;
    image3x3x3(i,j) = (1/9)*sum(sum(imageMascara));
  endfor
endfor

imageborda7( 4:(size(imageborda7,1)-3),4:(size(imageborda7,2)-3) ) = image;
for i = 1 : size(image,1)
  for j = 1 : size(image,2)
    newimage = imageborda7(i : i+6, j : j+6);
    imageMascara = newimage.*mascara7;
    image7(i,j) = (1/49)*sum(sum(imageMascara));
  endfor
endfor

figure();

subplot(1,4,1);
imshow(image);

subplot(1,4,2);
imshow(uint8(image3));

subplot(1,4,3);
imshow(uint8(image7));

subplot(1,4,4);
imshow(uint8(image3x3x3));