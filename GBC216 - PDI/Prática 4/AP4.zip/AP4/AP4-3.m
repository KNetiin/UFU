cd 'C:\Users\netii\Documents\PDI\AP4'

[oldimage, map] = imread('sta2noi1.png');

image = ind2gray(oldimage,map);
image = uint8(255*image);

figure;
subplot(1,3,1);
imshow(image);

imageborda3 = zeros( (size(image) + 2) );
imageborda7 = zeros( (size(image) + 6) );

image3 = double(image);
image7 = double(image);

imageborda3( 2:(size(imageborda3,1)-1),2:(size(imageborda3,2)-1) ) = image;
imageborda7( 4:(size(imageborda7,1)-3),4:(size(imageborda7,2)-3) ) = image;

for i = 1 : size(image,1)
  for j = 1 : size(image,2)
    matriz3 = imageborda3(i : i+2, j : j+2);
    matriz7 = imageborda7(i : i+6, j : j+6);
    image3(i,j) = median(matriz3(:));
    image7(i,j) = median(matriz7(:));
  endfor
endfor

subplot(1,3,2);
imshow(uint8(image3));
subplot(1,3,3);
imshow(uint8(image7));