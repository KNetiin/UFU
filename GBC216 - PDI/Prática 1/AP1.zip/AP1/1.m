cd 'C:\Users\netii\Documents\PDI\AP1'

image = imread('relogio.tif');

proporcao300 = uint64(1250/300);
proporcao150 = uint64(1250/150);
proporcao72 = uint64(1250/72);

tamanho1250 = uint64(size(image)); 
tamanho300 = [ uint64( tamanho1250(1)/proporcao300 ), uint64(tamanho1250(2)/proporcao300) ];
tamanho150 = [ uint64( tamanho1250(1)/proporcao150 ), uint64(tamanho1250(2)/proporcao150) ];
tamanho72 = [ uint64( tamanho1250(1)/proporcao72 ), uint64(tamanho1250(2)/proporcao72) ];

image300 = uint8( zeros( tamanho300 ) );
image150 = uint8( zeros( tamanho150 ) );
image72 = uint8( zeros( tamanho72 ) );

for i = 1 : tamanho300(1)
  for j = 1 : tamanho300(2)
    image300(i,j) = image(uint64((i - 1)*proporcao300 + 1),uint64((j - 1)*proporcao300 + 1));
  endfor
endfor

for i = 1 : tamanho150(1)
  for j = 1 : tamanho150(2)
    image150(i,j) = image(uint64((i - 1)*proporcao150 + 1),uint64((j - 1)*proporcao150 + 1));
  endfor
endfor

for i = 1 : tamanho72(1)
  for j = 1 : tamanho72(2)
    image72(i,j) = image(uint64((i - 1)*proporcao72 + 1),uint64((j - 1)*proporcao72 + 1));
  endfor
endfor
  
  figure();
  subplot(1,4,1);
  imshow(image);
  subplot(1,4,2);
  imshow(image300);
  subplot(1,4,3);
  imshow(image150);
  subplot(1,4,4);
  imshow(image72);