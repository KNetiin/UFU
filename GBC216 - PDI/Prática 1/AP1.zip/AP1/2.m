cd 'C:\Users\netii\Documents\PDI\AP1'

image = double(imread('ctskull-256.tif'));

image128 = zeros(size(image));
image64 = zeros(size(image));
image32 = zeros(size(image));
image16 = zeros(size(image));
image8 = zeros(size(image));
image4 = zeros(size(image));
image2 = zeros(size(image));

maux = image < 128;

image256 = uint8(image);
image128 = uint8(((ceil((image.+1)/2) * 2).-1) - maux*2);
image64 = uint8(((ceil((image.+1)/4) * 4).-1) - maux*4);
image32 = uint8(((ceil((image.+1)/8) * 8).-1) - maux*8);
image16 = uint8(((ceil((image.+1)/16) * 16).-1) - maux*16);
image8 = uint8(((ceil((image.+1)/32) * 32).-1) - maux*32);
image4 = uint8(((ceil((image.+1)/64) * 64).-1) - maux*64);
image2 = uint8(((ceil((image.+1)/128) * 128).-1) - maux*128);

figure();

subplot(2,4,1);
imshow(image256);
subplot(2,4,2);
imshow(image128);
subplot(2,4,3);
imshow(image64);
subplot(2,4,4);
imshow(image32);
subplot(2,4,5);
imshow(image16);
subplot(2,4,6);
imshow(image8);
subplot(2,4,7);
imshow(image4);
subplot(2,4,8);
imshow(image2);
