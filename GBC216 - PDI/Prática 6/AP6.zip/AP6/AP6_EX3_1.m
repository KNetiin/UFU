pkg load image;
#mask = fspecial('gaussian');
#imgauss = conv2(img,mask);
#imgauss = conv2(img,mask,'valid');

###############################################################
image_rgb = imread('insitu107595.jpg');

image_r = double(image_rgb(:,:,1));
image_g = double(image_rgb(:,:,2));
image_b = double(image_rgb(:,:,3));

image_gray = (image_r + image_g + image_b)/3;

figure();
subplot(1,3,1);
imshow(uint8(image_gray));
subplot(1,3,2);
imhist(uint8(image_gray));

hist_norm = imhist(uint8(image_gray));
hist_norm = hist_norm/sum(hist_norm(:));
hist_norm = hist_norm';

index = 0:255;
mi_global = sum(hist_norm.*index);
var_global = hist_norm.*( (index - mi_global).*(index - mi_global) );

ind_max = 0;
max = 0;

for k = 1 : 255
  p1 = sum(hist_norm(1:k));
  p2 = 1 - p1;
  
  mi_r1 = ( sum(hist_norm(1:k) .* index(1:k)) )/p1;
  mi_r2 = ( sum(hist_norm(k+1:256) .* index(k+1:256)) )/p2;
  
  var_r1 = ( p1*( (mi_r1 - mi_global)*(mi_r1 - mi_global) ) );
  var_r2 = ( p2*( (mi_r2 - mi_global)*(mi_r2 - mi_global) ) );

  var_r = ( var_r1 + var_r2 );
  
  if(var_r > max)
    max = var_r;
    ind_max = k;
  endif
  
endfor 

image_div = image_gray > ind_max;
subplot(1,3,3);
imshow(uint8(image_div*255));

###############################################################

image_rgb2 = imread('insitu107596.jpg');

image_r2 = double(image_rgb2(:,:,1));
image_g2 = double(image_rgb2(:,:,2));
image_b2 = double(image_rgb2(:,:,3));

image_gray2 = (image_r2 + image_g2 + image_b2)/3;

figure();
subplot(1,3,1);
imshow(uint8(image_gray2));
subplot(1,3,2);
imhist(uint8(image_gray2));

hist_norm = imhist(uint8(image_gray2));
hist_norm = hist_norm/sum(hist_norm(:));
hist_norm = hist_norm';

index = 0:255;
mi_global = sum(hist_norm.*index);
var_global = hist_norm.*( (index - mi_global).*(index - mi_global) );

ind_max = 0;
max = 0;

for k = 1 : 255
  p1 = sum(hist_norm(1:k));
  p2 = 1 - p1;
  
  mi_r1 = ( sum(hist_norm(1:k) .* index(1:k)) )/p1;
  mi_r2 = ( sum(hist_norm(k+1:256) .* index(k+1:256)) )/p2;
  
  var_r1 = ( p1*( (mi_r1 - mi_global)*(mi_r1 - mi_global) ) );
  var_r2 = ( p2*( (mi_r2 - mi_global)*(mi_r2 - mi_global) ) );

  var_r = ( var_r1 + var_r2 );
  
  if(var_r > max)
    max = var_r;
    ind_max = k;
  endif
  
endfor

image_div2 = image_gray2 > ind_max;

subplot(1,3,3);
imshow(uint8(image_div2*255));

###############################################################

image_rgb3 = imread('insitu107597.jpg');

image_r3 = double(image_rgb3(:,:,1));
image_g3 = double(image_rgb3(:,:,2));
image_b3 = double(image_rgb3(:,:,3));

image_gray3 = (image_r3 + image_g3 + image_b3)/3;

figure();
subplot(1,3,1);
imshow(uint8(image_gray3));
subplot(1,3,2);
imhist(uint8(image_gray3));

hist_norm = imhist(uint8(image_gray3));
hist_norm = hist_norm/sum(hist_norm(:));
hist_norm = hist_norm';

index = 0:255;
mi_global = sum(hist_norm.*index);
var_global = hist_norm.*( (index - mi_global).*(index - mi_global) );

ind_max = 0;
max = 0;

for k = 1 : 255
  p1 = sum(hist_norm(1:k));
  p2 = 1 - p1;
  
  mi_r1 = ( sum(hist_norm(1:k) .* index(1:k)) )/p1;
  mi_r2 = ( sum(hist_norm(k+1:256) .* index(k+1:256)) )/p2;
  
  var_r1 = ( p1*( (mi_r1 - mi_global)*(mi_r1 - mi_global) ) );
  var_r2 = ( p2*( (mi_r2 - mi_global)*(mi_r2 - mi_global) ) );

  var_r = ( var_r1 + var_r2 );
  
  if(var_r > max)
    max = var_r;
    ind_max = k;
  endif
  
endfor

image_div3 = image_gray3 > ind_max;

subplot(1,3,3);
imshow(uint8(image_div3*255));

###############################################################