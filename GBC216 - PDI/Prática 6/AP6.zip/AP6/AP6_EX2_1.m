pkg load image;
#mask = fspecial('gaussian');
#imgauss = conv2(img,mask);
#imgauss = conv2(img,mask,'valid');

###############################################################
image_rgb = imread('insitu107595.jpg');

image_r = double(image_rgb(:,:,1));
image_g = double(image_rgb(:,:,2));
image_b = double(image_rgb(:,:,3));

image_gray = (image_r + image_g + image_b)/3;

figure();
subplot(1,3,1);
imshow(uint8(image_gray));
subplot(1,3,2);
imhist(uint8(image_gray));

delta_t = 1;
t0 = (min(image_gray(:)) + max(image_gray(:)))/2;
condition = true;
while condition
  g1 = find(image_gray <= t0);
  g2 = find(image_gray > t0);
  
  u1 = mean(image_gray(g1));
  u2 = mean(image_gray(g2));
  
  t1 = (u1 + u2)/2;
  
  if(abs(t1 - t0) <= delta_t)
    condition = false;
  else
    t0 = t1;
  end 
end

image_div = image_gray > t0;
subplot(1,3,3);
imshow(uint8(image_div*255));

###############################################################

image_rgb2 = imread('insitu107596.jpg');

image_r2 = double(image_rgb2(:,:,1));
image_g2 = double(image_rgb2(:,:,2));
image_b2 = double(image_rgb2(:,:,3));

image_gray2 = (image_r2 + image_g2 + image_b2)/3;

figure();
subplot(1,3,1);
imshow(uint8(image_gray2));
subplot(1,3,2);
imhist(uint8(image_gray2));

delta_t2 = 1;
t02 = (min(image_gray2(:)) + max(image_gray2(:)))/2;
condition2 = true;
while condition2
  g12 = find(image_gray2 <= t02);
  g22 = find(image_gray2 > t02);
  
  u12 = mean(image_gray2(g12));
  u22 = mean(image_gray2(g22));
  
  t12 = (u12 + u22)/2;
  
  if(abs(t12 - t02) <= delta_t2)
    condition2 = false;
  else
    t02 = t12;
  end 
end

image_div2 = image_gray2 > t02;

subplot(1,3,3);
imshow(uint8(image_div2*255));

###############################################################

image_rgb3 = imread('insitu107597.jpg');

image_r3 = double(image_rgb3(:,:,1));
image_g3 = double(image_rgb3(:,:,2));
image_b3 = double(image_rgb3(:,:,3));

image_gray3 = (image_r3 + image_g3 + image_b3)/3;

figure();
subplot(1,3,1);
imshow(uint8(image_gray3));
subplot(1,3,2);
imhist(uint8(image_gray3));

delta_t3 = 1;
t03 = (min(image_gray3(:)) + max(image_gray3(:)))/2;
condition3 = true;
while condition3
  g13 = find(image_gray3 <= t03);
  g23 = find(image_gray3 > t03);
  
  u13 = mean(image_gray3(g13));
  u23 = mean(image_gray3(g23));
  
  t13 = (u13 + u23)/2;
  
  if(abs(t13 - t03) <= delta_t3)
    condition3 = false;
  else
    t03 = t13;
  end 
end

image_div3 = image_gray3 > t03;

subplot(1,3,3);
imshow(uint8(image_div3*255));

###############################################################