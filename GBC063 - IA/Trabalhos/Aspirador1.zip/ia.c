#include <stdio.h>
#include <stdlib.h>
#include <windows.h>


void imprime(int *vetor, int agente)
{
    system("cls");
    if(vetor[0] == 0) printf(". ");
    else printf("* ");
    if(vetor[1] == 0) printf(". ");
    else printf("* ");
    if(agente == 0) printf("\nA");
    else printf("\n  A");
}

int limpo(int *vetor,int tam)
{
    int i;
    for(i = 0; i < tam; i++) if(vetor[i] == 1) return 0;
    return 1;
}

int main()
{
    int vetor[2];
    int agente, caminho;
    char aux;

    printf("Digite onde o agente vai comecar(0/1)\n");
    scanf("%d",&agente);
    setbuf(stdin,NULL);
    printf("Havera sujeira em A?(S/N)\n");
    scanf("%c",&aux);
    if(toupper(aux) == 'S') vetor[0] = 1;
    else if(toupper(aux) == 'N') vetor[0] = 0;
    else printf("Resposta Errada\n");

    printf("Havera sujeira em B?(S/N)\n");
    setbuf(stdin,NULL);
    scanf("%c",&aux);
    if(toupper(aux) == 'S') vetor[1] = 1;
    else if(toupper(aux) == 'N') vetor[1] = 0;
    else printf("Resposta Errada\n");

    imprime(vetor,agente);

    while(limpo(vetor,2) == 0)
    {
        Sleep(2500);
        if(vetor[agente] == 1) vetor[agente] = 0;
        else if(agente == 0) agente = 1;
        else agente = 0;
        imprime(vetor,agente);
    }
    return 0;

}
