#include <stdio.h>
#include <stdlib.h>
#include <windows.h>

void imprime(int *vetor, int agente, int tamanho)
{
    system("cls");
    //printf("agente : %d\n",agente);
    int i;
    for(i = 0; i < tamanho; i++)
    {
        if(vetor[i] == 0) printf(". ");
        else printf("* ");
    }
    printf("\n");
    for(i = 0; i < agente; i++) printf("  ");
    printf("A");
    return;
}

int limpo(int *vetor,int tam)
{
    int i;
    for(i = 0; i < tam; i++) if(vetor[i] == 1) return 0;
    return 1;
}

int main()
{
    int *vetor;
    int i, agente, tamanho, di = 1;
    char aux;

    printf("Digite o tamanho do espaco: ");
    scanf("%d",&tamanho);

    vetor = (int*) malloc(tamanho*sizeof(int));

    printf("Digite a posicao que o agente esta: ");
    scanf("%d",&agente);

    for(i = 0; i < tamanho; i++) vetor[i] = 1;

    imprime(vetor,agente,tamanho);

    while(1)//limpo(vetor,2) == 0)
    {
        Sleep(1000);
        if(vetor[agente] == 1) vetor[agente] = 0;
        else
        {
            if((agente + 1) == tamanho) di = 0;
            else if(agente == 0) di = 1;

            if(di == 1) agente = agente + 1;
            else if(di == 0) agente = agente - 1;
        }
        imprime(vetor,agente,tamanho);
    }
    return 0;

}
