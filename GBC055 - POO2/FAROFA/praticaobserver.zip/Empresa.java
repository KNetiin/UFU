package praticaobserver;

import java.util.*;

public class Empresa implements Servidor{

    ArrayList<Observador> listaob;
    String nome;
    float valor;
     
    public Empresa(String n, float f){
        this.listaob = new ArrayList();
        this.valor = f;
        this.nome = n;
    }
    @Override
    public void SetValor(float newvalor) {
        this.valor = newvalor;
        this.notificarObservadores();
    }

    @Override
    public float GetValor() {
        return this.valor;
    }
    
    @Override
    public String GetNome() {
        return this.nome;
    }

    @Override
    public void registrarObservador(Observador o) {
        this.listaob.add(o);
    }

    @Override
    public void removerObservador(Observador o) {
        int i = this.listaob.indexOf(o);
        if(i >= 0)
        {
             this.listaob.remove(i); 
        }
    }

    @Override
    public void notificarObservadores() {
        for ( int i = 0; i < this.listaob.size(); i++)
        {
            Observador newo = (Observador) this.listaob.get(i);
            newo.exibir();
        }
    }
    
}
