package praticaobserver;

public interface HomeBroker {

    public void exibir();
}
