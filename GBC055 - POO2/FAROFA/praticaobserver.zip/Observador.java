package praticaobserver;

public class Observador implements HomeBroker{
    
    String nome;
    Servidor dados;
    
    public Observador(String n, Servidor s)
    {
        this.nome = n;
        this.dados = s;
    }
    
    @Override
    public void exibir()
    {
        System.out.println("Nome: " + this.dados.GetNome() + "  Valor: " +  this.dados.GetValor());
    }
}