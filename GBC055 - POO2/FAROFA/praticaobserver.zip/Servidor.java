package praticaobserver;

public interface Servidor {
    
    public void SetValor(float newvalor);
    public float GetValor();
    public String GetNome();
    
    public void registrarObservador(Observador o);
    public void removerObservador(Observador o);
    public void notificarObservadores();
}
