//Integrantes:  Antonio Carlos Neto  11611BCC054
//              Lucas Rossi Rabelo   11611BCC044
package praticaobserver;


public class PraticaObserver {

    
    public static void main(String[] args) {
        Empresa um = new Empresa("Disney",80f);
        Empresa dois = new Empresa("Petrobras",222f);
        Empresa tres = new Empresa("Vale",95f);
        
        Observador uno = new Observador("Farofa CO",um);
        um.registrarObservador(uno);
        Observador dos = new Observador("Marcelo CO",um);
        um.registrarObservador(dos);
        Observador tes = new Observador("Netiin CO",dois);
        dois.registrarObservador(tes);
        Observador quato = new Observador("Adriano CO",dois);
        dois.registrarObservador(quato);
        Observador cico = new Observador("Assustado CO",tres);
        tres.registrarObservador(cico);
        Observador ses = new Observador("Mercedes CO",tres);
        tres.registrarObservador(ses);
        Observador seite = new Observador("Palmeiras CO",tres);
        tres.registrarObservador(seite);
        
        um.SetValor(39f);
        dois.SetValor(539f);
        tres.SetValor(358f);
        
        um.SetValor(485f);
        dois.SetValor(841f);
        tres.SetValor(54f);
        
    }
    
}
