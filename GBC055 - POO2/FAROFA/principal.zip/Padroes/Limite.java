package principal.Padroes;


public abstract class Limite {
        
    public abstract void t_limite();
}
