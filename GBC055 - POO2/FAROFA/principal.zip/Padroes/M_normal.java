
package principal.Padroes;


public class M_normal extends Mensalidade {
    public void t_mensalidade(){
        System.out.println("Mensalidade Normal!");
    }
}
