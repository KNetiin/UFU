
package principal.Padroes;


public class M_baixa extends Mensalidade {
    public void t_mensalidade(){
        System.out.println("Mensalidade Baixa!");
    }
}
