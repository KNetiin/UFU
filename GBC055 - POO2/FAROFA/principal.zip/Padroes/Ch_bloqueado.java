
package principal.Padroes;


public class Ch_bloqueado extends Limite {
    
    public void t_limite(){
        System.out.println("Cheque Bloqueado!");
    }
}
