
package principal.Padroes;


public class R_normal extends Rentabilidade {
    public void t_rentabilidade(){
        System.out.println("Rentabilidade Normal!");
    }
}
