
package principal.Padroes;


public class M_simplificada extends Movimentacao {
    
    public void t_movimentacao(){
         System.out.println("Movimentação Simplificada (Caixa eletrônico, Cartão de Débito)!");
     }  
}
