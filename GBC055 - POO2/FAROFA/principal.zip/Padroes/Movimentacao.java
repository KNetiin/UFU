
package principal.Padroes;


public abstract class Movimentacao {
    
    public abstract void t_movimentacao();    
}
