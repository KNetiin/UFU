
package principal.Padroes;


public class M_completa extends Movimentacao {
 
     public void t_movimentacao(){
         System.out.println("Movimentação Completa (Caixa eletrônico, Cartão de Débito, Cartão de Crédito, Homebanking)!");
     }   
    
}
