
package principal.Padroes;


public abstract class Rentabilidade {
        public abstract void t_rentabilidade();
}
