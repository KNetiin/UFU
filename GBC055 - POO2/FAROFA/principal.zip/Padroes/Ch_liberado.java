
package principal.Padroes;


public class Ch_liberado extends Limite {
    
        public void t_limite(){
            System.out.println("Cheque Liberado!");
        }
}
