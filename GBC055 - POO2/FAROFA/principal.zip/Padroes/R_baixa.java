
package principal.Padroes;


public class R_baixa extends Rentabilidade {
        
    public void t_rentabilidade(){
        System.out.println("Rentabilidade Baixa!");
    }
   
}
