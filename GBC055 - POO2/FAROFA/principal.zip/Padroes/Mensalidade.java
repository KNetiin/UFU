
package principal.Padroes;


public abstract class Mensalidade {
        public abstract void t_mensalidade();
}
