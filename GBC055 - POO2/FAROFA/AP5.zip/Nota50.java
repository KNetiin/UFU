package ap5;

public class Nota50 extends BancoChain{
 
    public Nota50(BancoChain prox, int q)
    {
        this.next = prox;
        this.quantidade = q;
        this.id = "50";
    }   
    
    public void efetuasaque(int quantidade)
    {
        int quantia = 0;
        int quociente = quantidade / 50;
        if(quociente > this.quantidade) quantia = (this.quantidade * 50);
        else quantia = (quociente * 50);
            System.out.println((quantia/50) + " notas de R$50");
        if(this.next != null) this.next.efetuasaque(quantidade - quantia);
        else if((quantidade - quantia) == 0) System.out.println("Saque Completo!!!");
        else if((quantidade - quantia) != 0) System.out.println("Saque Incompleto!!!");
    }
}
