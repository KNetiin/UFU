package ap5;

public class Nota20 extends BancoChain{
    
    public Nota20(BancoChain prox, int q)
    {
        this.next = prox;
        this.quantidade = q;
        this.id = "20";
    }
    
    public void efetuasaque(int quantidade)
    {
        int quantia = 0;
        int quociente = quantidade / 20;
        if(quociente > this.quantidade) quantia = (this.quantidade * 20);
        else quantia = (quociente * 20);
        System.out.println((quantia/20) + " notas de R$20");
        if(this.next != null) this.next.efetuasaque(quantidade - quantia);
        else if((quantidade - quantia) == 0) System.out.println("Saque Completo!!!");
        else if((quantidade - quantia) != 0) System.out.println("Saque Incompleto!!!");
    }
}
