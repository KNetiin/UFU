//Lucas Rossi Rabelo 11611BCC044    
//Antonio Carlos Neto 11611BCC054
package ap5;

import java.util.ArrayList;

public class AP5 {

    public static void main(String[] args) 
    {

        /*
        BancoChain nota_menor = new Nota5(null);
        BancoChain nota_2 = new Nota10(nota_menor);
        BancoChain nota_3 = new Nota20(nota_2);
        BancoChain nota_4 = new Nota50(nota_3);
        BancoChain nota_5 = new Nota100(nota_4);
         */
        int v[] = new int[5];
        v[0] = 2;
        v[1] = 50;
        v[2] = 0;
        v[3] = 2;
        v[4] = 0;
        BancoChain nota_maior;
        nota_maior = BancoChain.criaCadeia(v);

        nota_maior.efetuasaque(370);
        //nota_5.efetuasaque(150);
    }
    
}
