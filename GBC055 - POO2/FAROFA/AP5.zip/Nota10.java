package ap5;

public class Nota10 extends BancoChain{
    
    public Nota10(BancoChain prox, int q)
    {
        this.next = prox;
        this.quantidade = q;
        this.id = "10";
    }
    
    public void efetuasaque(int quantidade)
    {
        int quantia = 0;
        int quociente = quantidade / 10;
        if(quociente > this.quantidade) quantia = (this.quantidade * 10);
        else quantia = (quociente * 10);
        System.out.println((quantia/10) + " notas de R$10");
        if(this.next != null) this.next.efetuasaque(quantidade - quantia);
        else if((quantidade - quantia) == 0) System.out.println("Saque Completo!!!");
        else if((quantidade - quantia) != 0) System.out.println("Saque Incompleto!!!");
    }
}
