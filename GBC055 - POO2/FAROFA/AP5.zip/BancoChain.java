package ap5;

public abstract class BancoChain {    
    BancoChain next;
    int quantidade;
    String id;
    

    public abstract void efetuasaque(int quantidade);
    
    public static BancoChain criaCadeia(int v[]){
        BancoChain anterior = null;
        
        if (v[4] != 0){
            BancoChain notas_5 = new Nota5(null, v[4]);
            anterior = notas_5;
        }
        if (v[3] != 0){
            BancoChain notas_10 = new Nota10(anterior, v[3]);
            anterior = notas_10;
        }
        if (v[2] != 0){
            BancoChain notas_20 = new Nota20(anterior, v[2]); 
            anterior = notas_20;
        }
        if (v[1] != 0){
            BancoChain notas_50 = new Nota50(anterior, v[1]);
            anterior = notas_50;
        }
        if (v[0] != 0){
            BancoChain notas_100 = new Nota100(anterior, v[0]);
            anterior = notas_100;
        }
        return anterior;
    }
    
}
