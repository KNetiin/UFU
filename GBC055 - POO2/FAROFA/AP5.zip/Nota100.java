package ap5;

public class Nota100 extends BancoChain {
    
    public Nota100(BancoChain prox, int q)
    {
        this.next = prox;
        this.quantidade = q;
        this.id = "100";
    }
    
    public void efetuasaque(int quantidade)
    {
        int quantia = 0;
        int quociente = quantidade / 100;
        if(quociente > this.quantidade) quantia = (this.quantidade * 100);
        else quantia = (quociente * 100);
        System.out.println((quantia/100) + " notas de R$100");
        if(this.next != null) this.next.efetuasaque(quantidade - quantia);
        else if((quantidade - quantia) == 0) System.out.println("Saque Completo!!!");
        else if((quantidade - quantia) != 0) System.out.println("Saque Incompleto!!!");
    }
}
