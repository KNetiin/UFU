package ap5;

public class Nota5 extends BancoChain{
    
    public Nota5(BancoChain prox, int q)
    {
        this.next = prox;
        this.quantidade = q;
        this.id = "5";
    }
     
    public void efetuasaque(int quantidade)
    {
        int quantia = 0;
        int quociente = quantidade / 5;
        if(quociente > this.quantidade) quantia = (this.quantidade * 5);
        else quantia = (quociente * 5);
        System.out.println((quantia/5) + " notas de R$5");
        if(this.next != null) this.next.efetuasaque(quantidade - quantia);
        else if((quantidade - quantia) == 0) System.out.println("Saque Completo!!!");
        else if((quantidade - quantia) != 0) System.out.println("Saque Incompleto!!!");
    }
}
