package batalhanaval;

import java.util.ArrayList;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*; 

public class Jogador
{
    final private String nome;
    ArrayList<Navio> navios = new ArrayList<>();
    public Grade grade;
    
    
    public Jogador(String nome)
    {
        this.grade = new Grade("DEFESA");
        this.nome = nome;
        
        /*******************************CRIANDO NAVIOS**********************************/
        Navio cinco11 = new Navio(5,"Encouraçado");
        cinco11.posicao.add("A1");
        this.navios.add(cinco11);
        
        Navio quatro11 = new Navio(4,"Cruzador");
        this.navios.add(quatro11);
        
        Navio tres11 = new Navio(3,"Contra Torpedo");
        Navio tres22 = new Navio(3,"Contra Torpedo");
        this.navios.add(tres11);
        this.navios.add(tres22);
        
        Navio dois11 = new Navio(2,"Destroyer");
        Navio dois22 = new Navio(2,"Destroyer");
        Navio dois33 = new Navio(2,"Destroyer");
        this.navios.add(dois11);
        this.navios.add(dois22);
        this.navios.add(dois33);
        
        Navio um11 = new Navio(1,"Submarino");
        Navio um22 = new Navio(1,"Submarino");
        Navio um33 = new Navio(1,"Submarino");
        Navio um44 = new Navio(1,"Submarino");
        this.navios.add(um11);
        this.navios.add(um22);
        this.navios.add(um33);
        this.navios.add(um44);
        
        //////////////////////////////////////////////////////////////////////////////////
        
            do
            {
            }while("".equals(Grade.registrador));
        System.out.println("DEUUU BAUM POHA" + Grade.registrador);
    }
    
    public void adiciona_navio(Navio n)
    {
        navios.add(n);
    }
    
    public Navio getNavio(int posicao)
    {
        return this.navios.get(posicao);
    }
    
    public boolean verifica_local(String xy)
    {
        boolean ret = false;
        for(int i = 0; i < this.navios.size(); i++)
        {
            for(int j = 0; j < this.navios.get(i).posicao.size(); j++)
            {
                if(xy.equals(this.navios.get(i).posicao.get(j)) == true) ret = true;
            }
        }
        return ret;
    }
}
