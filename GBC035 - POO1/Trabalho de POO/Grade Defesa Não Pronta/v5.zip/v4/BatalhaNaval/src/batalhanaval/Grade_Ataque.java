package batalhanaval;

import java.awt.*;
import java.awt.event.*;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.Border;
import javax.swing.JOptionPane;


public class Grade_Ataque {
    String jogador1;
    String jogador2;
    
    public Grade_Ataque(String j1, String j2){
       this.jogador1 = j1;
       this.jogador2 = j2;
       
       JFrame ataque = new JFrame("Batalha Naval");
       ataque.setSize(1050,650);
       ataque.setResizable(false);
        JPanel painel = new JPanel(new BorderLayout());
        String x = "Turno do jogador: " + this.jogador1;
        JLabel mensagem = new JLabel (x);
        ataque.getContentPane().add(painel);
       JPanel central = new JPanel();
        ataque.add(central, BorderLayout.NORTH);
        central.add(mensagem);
       mensagem.setFont(new Font("Broadway", Font.BOLD, 22));
       central.setBackground(new Color(242,242,242));
        //Daqui pra cima é a criação da Janela, e do JLabel centralizado em cima do backgound color cinza claro 
       
        
        JPanel ataque1 = new JPanel(new GridLayout(10,10)); //Grade da esquerda
        JPanel ataque2 = new JPanel(new GridLayout(10,10)); //Grade da direita
        
        JPanel centro = new JPanel();
        ataque.add(centro, BorderLayout.CENTER);
        centro.setPreferredSize(new Dimension(60,650));
        centro.setBackground(new Color(242,242,242));
        centro.setLayout(new BorderLayout());
        ataque.add(ataque2, BorderLayout.WEST);
        ataque.add(ataque1, BorderLayout.EAST);
        
        ataque1.setPreferredSize(new Dimension(500,640));
        ataque2.setPreferredSize(new Dimension(500,640));
        
        //Daqui pra cima é a criação dos paineis que terão os botões
        ////////////////////////////////////////////////////////////////////////////////////////////////////////
        //Adicionar os botões das posições dos barcos nos gridlayouts do centro do borderlayout
        
        String coisa;
        coisa = "VS";
        JLabel vs = new JLabel(coisa);
        vs.setFont(new Font("Broadway",Font.BOLD,22));
        vs.setVerticalTextPosition(JLabel.CENTER);
        vs.setHorizontalAlignment(JLabel.CENTER);
        
        centro.add(vs, BorderLayout.CENTER);
        
        String[] posicao = {"A","B","C","D","E","F","G","H","I","J"};
        
        ActionListener descobreTecla = new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                JButton botaoClicado = (JButton)e.getSource();
                
            }
        };
        
        for(int i=0; i<posicao.length; i++) //Disposição dos botões no painel da esquerda
        {
            for(int j = 1; j < 11; j++)
            {
                ((JButton)ataque2.add(new JButton(posicao[i]+j,new ImageIcon("Imagens/Mar/"+posicao[i]+j+".png")))).addActionListener(descobreTecla);
            } 
        }
        
        for(int i=0; i<posicao.length; i++) //Disposição dos botões no painel da direita
        {
            for(int j = 1; j < 11; j++)
            {
                ((JButton)ataque1.add(new JButton(posicao[i]+j,new ImageIcon("Imagens/Mar/"+posicao[i]+j+".png")))).addActionListener(descobreTecla);
            } 
        }
        
      
        
       ataque.setVisible(true);
       ataque.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       ataque.setLocationRelativeTo(null);
    }
}
