package batalhanaval;

import java.util.ArrayList;

public class BatalhaNaval
{
    private ArrayList<Jogador> jogadores = new ArrayList<>();
    boolean fim;
    
    public static void main(String[] args)
    {
       Jogador j1 = new Jogador("Neto");
       Grade_Ataque gradezikona = new Grade_Ataque("Batman","Capitão_Caverna");
        
    }
    
}
