#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define m 32749

int main()
{
  int periodo, x, a, count = 0, smallest_multiplier = 0;
  /*************Considerando x0 = 1;*************/
  //printf("Digite o valor de a\n");
  //scanf("%d",&a);
  //printf("a = %d\n", a);

  for(int i = 1; i < m; i++){
    a = i;

    periodo = 1;
    x = a;

    while (x != 1) {
      periodo++;
      x = (a * x)%m; /* beware of a * x overflow */
      //printf("%d ",x );
    }

    if (periodo == m - 1)
    {
      if(!smallest_multiplier) smallest_multiplier = a;
      count++;
      //printf("a = %d is a full-period multiplier\n",a);
    }
    //else printf("a = %d is not a full-period multiplier\n", a);
  }
  printf("Existe %d full-period multiplier\n",count);
  printf("Smallest Multiplier %d\n",smallest_multiplier);
  return 1;
}
