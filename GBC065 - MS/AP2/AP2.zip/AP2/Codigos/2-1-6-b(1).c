#include <stdlib.h>
#include <stdio.h>

#define max 32748

int main()
{
  int j, flag, largest_prime = 0;

  printf("O numero %d e divisivel por:\n",max);
  if(max%2 == 0) printf("%d, ",2);
  j = 3;
  while(j <= max/2){
    if(max%j == 0) printf("%d, ",j);
    j = j + 2;
  }
  return 1;
}
