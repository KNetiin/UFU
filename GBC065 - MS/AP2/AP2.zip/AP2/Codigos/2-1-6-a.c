#include <stdlib.h>
#include <stdio.h>

#define max 32767

int main()
{
  int i = max,
      j,
      flag,
      largest_prime = 0;

  while(!largest_prime && i > 1){
    if(i%2 == 0) flag = 0;
    else{
      flag = 1;
      j = 3;
      while(flag && j <= i/2){
        if(i%j == 0) flag = 0;
        j = j + 2;
      }
      if(flag == 1){
        largest_prime = i;
        printf("The largest prime modulus is : %d\n",largest_prime);
      }
    }
    i--;
  }
  return 1;
}
