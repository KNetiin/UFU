#include <stdlib.h>
#include <stdio.h>

#define tam 4
#define m 13
#define qt 12

long long int potencia(int x, int y){
  long long int resposta = x;
  y--;
  while(y){
    resposta = resposta*x;
    y--;
  }
  return resposta;
}

int main()
{
  int i,
      j,
      vetor[tam] = {1,5,7,11},
      number[qt] = {1,2,3,4,5,6,7,8,9,10,11,12};
  long long resultado;

  for(j = 0; j < qt; j++) {
    printf("\nCiclo do numero: %d\n",number[j]);
    for(i = 0; i < tam; i++) {
      resultado = potencia(number[j],vetor[i])%m;
      printf("%d^%d mod %d = %lld.\n",number[j], vetor[i], m, resultado);
    }
  }
  return 1;
}
