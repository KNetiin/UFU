#include <stdio.h>
#include <stdlib.h>
/*int gcd(int x, int y)
{
  int menor,
      i;

  if(y < x){
    menor = y;
    if(x % y == 0) return y;
  }
  else{
    menor = x;
    if(y % x == 0) return x;
  }
  menor = menor/2;

  for(i = menor; menor > 0; i--){
    if(x%i == 0 && y%i == 0) return i;
  }
  return -1;
}*/

int main()
{
  int m = 2147483647,
      a[6] = {630360016, 742938285, 950706376, 1226874159, 62089911, 1343714438 };

  for(int i = 0; i < 6; i++)
  {
    //if((gcd(a[i], (m-1)) == 1) && ( (m%a[i]) < (m/a[i]) )) printf("%d eh multipliers associated de m = %d\n",a[i],m );
    if((m%a[i]) < (m/a[i]) ) printf("%d eh multipliers associated de m = %d\n",a[i],m );
    else printf("%d nao eh multipliers associated de m = %d\n",a[i],m );
  }
  return 1;
}
