#include <stdio.h>
#include <stdlib.h>

/*int gcd(int x, int y)
{
  int menor,
      i;

  if(y < x){
    menor = y;
    if(x % y == 0) return y;
  }
  else{
    menor = x;
    if(y % x == 0) return x;
  }
  menor = menor/2;

  for(i = menor; menor > 0; i--){
    if(x%i == 0 && y%i == 0) return i;
  }
  return -1;
}*/

int g(int a, int m, int x)
{
  long long int newa = a,
                newm = m,
                newx = x,
                resultado = (newa*newx)%newm;

  //printf("A = %lld, M = %lld, X = %lld, AXmodM = %lld\n",newa,newm,newx,resultado);

  int resposta = resultado;

  //printf("RESPOSTA INT %d\n", resposta);
  return resposta;
}

int main()
{
  int a,
      x,
      m = 32749,//2147483647,
      count = 0,
      count2 = 0,
      periodo,
      smallest_multiplier = 0;

    for(int i = 1; i < m; i++){
      a = i;

      periodo = 1;
      x = a;

      while (x != 1) {
          periodo++;
          x = g(a,m,x);
        }

        if (periodo == m - 1)
        {
          //if(gcd(a,m-1) == 1){
          if( (m%a) < (m/a) ){
            count2++;
            if(!smallest_multiplier) smallest_multiplier = a;
            printf("a = %d is full-period modulus-compatible multiplier\n",a);

          }
          count++;
          //printf("a = %d is a full-period multiplier\n",a);
        }
        //else printf("a = %d is not a full-period multiplier\n", a);
      }

      printf("Existe %d full-period multiplier\n",count);
      printf("Existe %d full-period modulus-compatible multiplier\n",count2);
      printf("Smallest full-period modulus-compatible multiplier %d\n",smallest_multiplier);

  return 1;
}
