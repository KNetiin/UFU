#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define tam 16

int main()
{
  int m[16] = {2,3,5,7,11,13,17,19,23,29,31,37,41,43,47,53},
      periodo,
      x,
      a,
      count = 0,
      smallest_multiplier = 0;

  for(int k = 0; k < tam; k++)
  {
    count = 0;
    smallest_multiplier = 0;
    /*************Considerando x0 = 1;*************/
    for(int i = 1; i < m[k]; i++){
      a = i;

      periodo = 1;
      x = a;

      while (x != 1) {
        periodo++;
        x = (a * x)%m[k]; /* beware of a * x overflow */
        //printf("%d ",x );
      }

      if (periodo == m[k] - 1)
      {
        if(!smallest_multiplier) smallest_multiplier = a;
        count++;
        //printf("a = %d is a full-period multiplier\n",a);
      }
      //else printf("a = %d is not a full-period multiplier\n", a);
    }
    printf("M = %d\n",m[k]);
    printf("Existe %d full-period multiplier\n",count);
    printf("Smallest Multiplier %d\n\n",smallest_multiplier);
  }
  return 1;
}
