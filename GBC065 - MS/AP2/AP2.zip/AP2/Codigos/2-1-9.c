#include <stdlib.h>
#include <stdio.h>

#define max 2147483646
#define x 10

int main()
{
  long long int i = 0,
                j,
                flag,
                largest_prime = 0,
                count = 0,
                aux,
                resultado;

  /************DESCOBRINDO TAMANHO DO VETOR DIVISORES************/
  if(max%2 == 0) count++;
  j = 3;
  while(j <= max/2){
    if(max%j == 0) count++;
    j = j + 2;
  }

  /************CRIANDO E PREENCHENDO O VETOR DIVISORES************/

  long long int *divisores = (long long int*) malloc(sizeof(long long int)*count);

  if(max%2 == 0){
    divisores[i++] = 2;
    count++;
  }
  j = 3;
  while(j <= max/2){
    if(max%j == 0) divisores[i++] = j;
    j = j + 2;
  }

  /*****************DESCOBRINDO X PRIMOS ENTRE SI*****************/

  printf("Tamanho do vetor de divisores = %lld\n",count);
  //for(i = 0; i < count; i++) printf("%lld, ",divisores[i]);
  //printf("\n");

  i = 0;
  j = 0;
  aux = 0;
  while(i < x && aux < max){
    flag = 0;
    j = 0;
    aux++;

    while(flag == 0 && j < count){
      resultado = aux % divisores[j];
      if(resultado == 0) flag = 1;
      j++;
    }
    if(flag == 0){
      i++;
      printf("O numero %lld eh primo entre si\n",aux);
    }
  }
  return 1;
}
